const express = require('express');
const mongoose = require('mongoose');
const app = express();
const port = 3001;
const apiRoutes = require('./router');

app.use(express.json());
app.use('/api', apiRoutes);

mongoose.connect('mongodb+srv://saakiretro:Vegas%4031@cluster1.o8ih3eb.mongodb.net/webd_1', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useCreateIndex: true,
  useFindAndModify: false
})
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

app.listen(port, () => console.log(`Server running on port ${port}`));
