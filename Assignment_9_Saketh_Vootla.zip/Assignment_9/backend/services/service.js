const userModel = require('../models/model');

exports.authenticate = async (username, password) => {
  const user = await userModel.findByUsername(username);
  if (user && user.password === password) {
    return {
      id: user.id,
      username: user.username,
      // You can return more user fields or a token as needed
    };
  }
  return null;
};
