// Sample user data (You can replace this with an actual database connection)
const users = [
    { id: 1, username: 'user1', password: 'password1' },
    { id: 2, username: 'user2', password: 'password2' },
  ];
  
  exports.findByUsername = async (username) => {
    const user = users.find((user) => user.username === username);
    if (user) {
      return user;
    }
    return null;
  };
  