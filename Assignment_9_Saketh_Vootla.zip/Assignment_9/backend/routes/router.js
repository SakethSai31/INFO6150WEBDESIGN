const express = require('express');
const router = express.Router();
const controller = require('../controller/controller');

router.get('/user', controller.getUser);
router.post('/user/create', controller.createUser);
router.get('/user/getAll', controller.getAllUsers);
router.delete('/user/delete', controller.deleteUser);
router.put('/user/edit', controller.editUser);

module.exports = router;
