const userService = require('../services/service');

exports.getUser = (req, res, next) => {
  res.send("Hello from Express!");
};

exports.createUser = (req, res) => {
  const user = new User({
    fullName: req.body.fullName,
    email: req.body.email,
    password: req.body.password,
  });
  user
    .save()
    .then(() => {
      res.status(201).json({
        message: "New user has been added successfully",
      });
    })
    .catch((err) => {
      res.status(500).json({
        message: err.message,
      });
    });
};

exports.getAllUsers = (req, res, next) => {
  User.find()
  .select([])
  .then((documents) => {
    res.status(200).json({
      message: "All the users details have been fetched successfully",
      users: documents,
    });
  });
};

exports.deleteUser = (req, res, next) => {
  if (req.body.email) {
    User.find({ email: req.body.email }, (err, user) => {
      if (user.length > 0) {
        User.deleteOne({ email: req.body.email }).then((result) => {
          console.log(result);
          res.status(200).json({ message: "User has been deleted successfully" });
        });
      } else {
        res.status(200).json({ message: "User not found!" });
      }
    });
  } else {
    res.status(200).json({ message: "Please provide Email" });
  }
};

exports.editUser = async (req, res) => {
  try {
    User.findOne({ email: req.body.email }, async (err, user) => {
      if (err) {
        return res.status(500).send({ message: "Error finding user", err });
      }

      if (!user) {
        return res.status(404).send({ message: "User not found" });
      }

      // Update the user's password and other fields as needed
      user.password = req.body.password;
      user.fullName = req.body.fullName;
      user.email = req.body.email;

      // Save the user
      try {
        await user.save();
        res.status(200).json({ message: "User has been updated successfully" });
      } catch (saveError) {
        res.status(500).send({ message: "Error updating user", saveError });
      }
    });
  } catch (error) {
    res.status(500).send({ message: "Error processing request", error });
  }
};
