import React from 'react';
import '../Main/MainPage.css';
import { Link } from 'react-router-dom';

export default function MainPage({ handleLogout, isLoggedIn }) {
  return (
    <div>
      <nav>
        {isLoggedIn ? (
          <>
            <Link to="/home">Home</Link>
            <Link to="/about">About</Link>
            <Link to="/profile">Profile</Link>
            <Link to="/jobs">Jobs</Link>
            <button onClick={handleLogout}>Log Out</button>
          </>
        ) : (
          <>
            <Link to="/LoginPage">Log In</Link>
          </>
        )}
      </nav>
      <footer>
        <div>This is footer</div>
      </footer>
    </div>
  );
}
