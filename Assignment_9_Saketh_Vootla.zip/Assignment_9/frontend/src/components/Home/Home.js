import React from "react";

function Home(){
    return(
        <div>
            This is Home page
        </div>
    )
}

export default Home