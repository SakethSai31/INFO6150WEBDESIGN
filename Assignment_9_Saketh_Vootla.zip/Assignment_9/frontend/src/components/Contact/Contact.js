import React from "react";

function Contact(){
    return(
        <div>
            This is Contact page
        </div>
    )
}

export default Contact