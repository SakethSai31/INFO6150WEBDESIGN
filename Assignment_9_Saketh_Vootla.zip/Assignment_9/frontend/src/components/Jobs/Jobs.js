import React from "react";

function Jobs(){
    return(
        <div>
            This is Jobs page
        </div>
    )
}

export default Jobs